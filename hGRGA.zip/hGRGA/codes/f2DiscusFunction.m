%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Discus Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Discus function
%}

function [fx] = f2DiscusFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

sumTerm = sum(X(2:end).^2);
fx =  (10^6 * X(1)^2) + sumTerm;

%% END