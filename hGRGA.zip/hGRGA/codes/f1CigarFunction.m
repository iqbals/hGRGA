%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Bent Cigar Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Bent Cigar function
%}

function [fx] = f1CigarFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

sumTerm = (10^6) * sum(X(2:end).^2);
fx =  X(1)^2 + sumTerm;

%% END