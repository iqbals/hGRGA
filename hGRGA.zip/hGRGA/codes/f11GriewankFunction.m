%{
Author: Sumaiya Iqbal, Computer Science, UNO ID # 2450707

Optimization Test Function Implementation

59. Griewank Function [40] (Continuous, Differentiable, Non-Separable, Scalable, Multimodal)
f(x) = (SUM(i=1 to n) ((x(i)^2) / 4000)) - ((MULT(i=1 to n) cos(x(i)/sqrt(i))) + 1
subject to -100 <= x(i) <= 100. 
The global minima is located at x* = f(0, ..., 0), f(x*) = 0;

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Greiwank function
%}

function [fx] = GriewankFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) <= 0
    error('Input should be atleast a singletone vector');
end

sumC = 0;                                                 % Initializing summation component            
mulC = 1;                                                 % Initializing multiplicative component   

n = length(X);
for i = 1:n
    sumC = sumC + ((X(i)^2)/4000);                        % summation component
    mulC = mulC * (cos(X(i)/sqrt(i)));                    % multiplicative component
end
fx =  sumC - mulC + 1;                                    % function output
%%