%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Michalewicz Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Michalewicz function
%}

function [fx] = f8MichalewiczFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

m = 10;
sumForm = 0;
N = length(X);
for i = 1:N
    sumForm = sumForm + ((sin(X(i))* (sin((i*(X(i)^2))/pi)^(2*m))));
end

fx =  (-1) * sumForm;

%% END