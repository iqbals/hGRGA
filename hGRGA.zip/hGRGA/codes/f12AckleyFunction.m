%{
Author: Sumaiya Iqbal, Computer Science, UNO ID # 2450707

Optimization Test Function Implementation
Ackley (Continuous, Differentiable, Non-Separable, Scalable, Multimodal)
subject to - 32 <= x(i) <= 32. 
The global minima is located at x* = f(0, 0), f(x*) = 0;

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Greiwank function
%}

function [fx] = AckleyFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

a = 20;
b = 0.2;
c = 2 * pi;

squareSum = 0;
cosineSum = 0;

N = length(X);
for d = 1:N
    squareSum = squareSum + (X(d)^2);
    cosineSum = cosineSum + cos(c*X(d));
end
fx =  ((-a)* exp(-b * sqrt(squareSum/N))) - (exp(cosineSum/N)) + a + exp(1);
%{
xx = X;
d = length(xx);

if (nargin < 4)
    c = 2*pi;
end
if (nargin < 3)
    b = 0.2;
end
if (nargin < 2)
    a = 20;
end

sum1 = 0;
sum2 = 0;
for ii = 1:d
	xi = xx(ii);
	sum1 = sum1 + xi^2;
	sum2 = sum2 + cos(c*xi);
end

term1 = -a * exp(-b*sqrt(sum1/d));
term2 = -exp(sum2/d);

y = term1 + term2 + a + exp(1);
fx = y;
%}
%% END