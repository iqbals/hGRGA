%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Schwefel 2.26 Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Schwefel 2.26 function
%}

function [fx] = f7SchwefelFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

sumForm = 0;
N = length(X);
for i = 1:N
    sumForm = sumForm + (X(i) * sin(sqrt(abs(X(i)))));
end

fx =  418.9829*N - sumForm;

%% END