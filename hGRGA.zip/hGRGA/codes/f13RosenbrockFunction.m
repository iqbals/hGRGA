%{
Author: Sumaiya Iqbal, Computer Science, UNO ID # 2450707

Optimization Test Function Implementation

105. Rosenbrock Function [73] (Continuous, Differentiable, Non-Separable, Scalable, Unimodal)
f105(x) = sum[100(xi+1 - (xi)^2)^2 + (xi - 1)^2]
subject to -30 <= xi <= 30. [DR. Hoque's paper: -2.048 to 2.048 is used]
A global minimum is located at f(x*) = f (1, 1), f(x*) = 0

Input: 
X   ---> input vector with x1, x2 values
Output:
fx  ---> Output of Rosenbrock function
%}

function [fx] = RosenbrockFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input vector should contain atleast two (x1, x2) values');
end

N = length(X);
sum = 0;
for i = 1:(N-1)
    sumPart = 100*((X(i)^2) - X(i+1))^2 + (1 - X(i))^2;
    sum = sum + sumPart;
end
fx =  sum;                                    % function output
%%