%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Styblinski_Tang Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Styblinski_Tang function
%}

function [fx] = f9Styblinski_TangFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

sumForm = 0;

N = length(X);
for i = 1:N
    sumForm = sumForm + (X(i)^4 - 16*X(i)^2 + 5*X(i));
end

fx =  0.5 * sumForm ;

%% END