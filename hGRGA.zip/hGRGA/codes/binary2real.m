%{
Author: Sumaiya Iqbal
Function for converting "binary to signed real" number
Input: 
d: integer part --- number of bits for decimal part of the number 
f: fraction part --- number of bits for fractional part of the number 
x: a vector with binary bits
 --- 1st bit (left most): sign bit
 --- 2 to (d+1) bits: decimal part
 --- (end-f+1) to end bits: fractional part
 Output:
r: real number converted from binary vector
%}

function [r] = binary2real(x, d, f) 
l = length(x);
sBit = x(1);
dBits = x(2:(d+1));
fBits = x((l-f+1):l);

dPart = bi2de(dBits, 'left-msb');           % binary to decimal

idx = find(fBits);                          % find the index
fPart = 0;

for k = 1:length(idx)                       % convert into real number
    fPart = fPart + 2^(-idx(k));
end
realBeta = (dPart + fPart);                 % converted real value
if sBit == 1
    realBeta = (-1) * realBeta;
end
r = realBeta;
