%{
Author: Sumaiya Iqbal, Computer Science, UNO ID # 2450707

Optimization Test Function Implementation
Levy 13
subject to -5 <= x(i) <= 10. 
The global minima is located at 
x* = f(0, 0), f(x*) = 0 
Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Levy13 function
%}

function [fx] = GriewankRosenFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end
fx = 0;
N = length(X);
x = zeros(N, 1);
for i = 1:N
    if(i == N)
        x1 = X(N);
        x2 = X(1);
    else
        x1 = X(i);
        x2 = X(i+1);
    end
    
    x = (100*(((x1^2)-x2)^2)) + ((x1-1)^2);
    fx =  fx + ((x^2 / 4000) - cos(x/sqrt(i)) + 1);
end

%% END