%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
NOTES: Runner of hGRGA for different number of Cycles
Return from GA:
    Min_Obj                 ---- minimum function value
    Min_Obj_Epoch           ---- epoch required for min function value
    best_beta               ---- best weight set
    Obj                     ---- best objective function values for all epoch
    twin_removal_parameters ---- twin removal paramaters
%}

clc
clear

nCycles = 20;               % number of cycles
nEpo = 2000;                % number of epoch, must match with hGRGA function code
nBe = 10;                   % number of beta/gene/variable/dimension, must match with hGRGA function code
to = 0;                     % target optima, must match with hGRGA function code

%% Collect output from GA
minObj_cycles = zeros(nCycles, 1);                  % minimum function value in each cycle
minObjEpoch_cycles = zeros(nCycles, 1);             % best epoch in each cycle
bestBeta_cycles = zeros(nBe, nCycles);              % best beta set of each cycle
OBJvalues_cycles = zeros(nEpo, nCycles);            % best obj value set of each cycle
elapsedTime_cycle = zeros(nCycles, 1);              % time needed in each cycle
error_cycle = zeros(nCycles, 1);                    % error in each cycle

%% RUN CYCLES/ITERATIONS
for cycle = 1:nCycles
    cycle
    
    tic;
    [Min_Obj, Min_Obj_Epoch, best_beta, Obj, twin_removal_parameters] = hGRGA(nEpo, nBe, to);
    toc
    elapsedTime_cycle(cycle) = toc;
     
    minObj_cycles(cycle) = Min_Obj;
    minObjEpoch_cycles(cycle) = Min_Obj_Epoch;
    bestBeta_cycles(:, cycle) = best_beta;
    OBJvalues_cycles(:, cycle) = Obj';
    error_cycle(cycle) = to - Min_Obj;
end

%% SHOW best values
BestMinima = min(minObj_cycles)                     % Best result (fitness)
AvgMinima = mean(minObj_cycles)                     % Mean result (fitness)
StdMinima = std(minObj_cycles)                      % standard deviation of result (fitness)    
AvgEpochMinima = mean(minObjEpoch_cycles)           % mean epoch required to reach best result per cycle
AvgTime = mean(elapsedTime_cycle)                   % mean time required for each cycle
AvgError = mean(abs(error_cycle))                   % Mean absolute error    

%% END
