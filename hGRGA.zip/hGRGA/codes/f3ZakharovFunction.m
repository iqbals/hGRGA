%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Zakharov Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Zakharov function
%}

function [fx] = f3ZakharovFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

sumForm2_3 = 0;

N = length(X);
for i = 1:N
    sumForm2_3 = sumForm2_3 + 0.5*i*X(i);
end

fx =  sum(X.^2) + (sumForm2_3)^2 + (sumForm2_3)^4;

%% END