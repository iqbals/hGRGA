%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Genetic Algorithm with homologous gene replacement plus Twin Removal

---- Elitism
---- Homologous gene Replacement
---- Roulette wheel
---- Single point crossover
---- Single point mutation
---- Twin removal
---- Checking for bouds after crossover and nutation
---- Replace with random real number if not within range 
     and convert into binary
---- For initial population, generated random real values within bounds 
     and then converted into binary 

 NOTES: Objective Function, #variable, range, #Bits need to be changed
%}

function [Min_Obj, Min_Obj_Epoch, best_beta, Obj, twin_removal_parameters] = hGRGA(nEpo, nBe, to)
%%------------------------------------ Initialization START%%----------------------------------------%%
%% terminating  condition 
target_optima = to;                         % target minima (dependent on functsion)
Max_Epoch = nEpo;                           % maximum number of epochs allowed

Min_Obj = Inf;                              % initialzing minimum objective
Min_Obj_Epoch = -1;                         % initializing epock number to achieve minimum objective

epoch=0;                                    % initialization of epoch
optima = Inf;                               % initializing the optima (Inf for minimization and -Inf for maximization)

Obj=zeros(1, Max_Epoch);                    % For per generation objective function value
for i = 1:Max_Epoch
    Obj(i) = target_optima;
end
Epo=zeros(1, Max_Epoch);                    % store epoch number

%% number of beta, bits and chromosome
nBeta = nBe;                                % number of variables (beta / weights) %% CHANGE
VRange = [-600; 600];                       % Range of variables (depends on Functions, see supplementary material) %% CHANGE

dBits = 10;                                 % decimal part (1 -- sign bit) %% CHANGE
fBits = 16;                                 % fractional part %% CHANGE
nBits = dBits + fBits + 1;                  % number of bits (% nBits = dBits + fBits + 1)
chromL = nBeta * nBits;                     % one chromosome length
popSize = 200;                              % number of chromosome

%% GA Parameter
eRate = 0.1;                                % Elite Rate = 10%
cRate = 0.8;                                % Cross Over Rate = 80%
mRate = 0.05;                               % Mutation Rate = 5%

nE = popSize * eRate;                       % number of elites    
nC = (popSize * cRate)/2;                   % number of crossover
nM = popSize * mRate;                       % number of mutation

%% Binary population initialization
population = round(rand(chromL, popSize));  % population of random 0 and 1
realBetaPop = ones(nBeta, popSize);         % Initialization of real valued beta population
fitness_obj = zeros(1, popSize);            % fitness matrix
pFitness = zeros(1, popSize);               % probability of fiteness 
%%------------------------------------ Initialization END%----------------------------------------%%

%%------------------------------------ Generate Initial Population Start----------------------------------------%%
%% Generate Random Real and Binary Population
for i = 1:popSize
    for j = 1: nBeta
        realBetaPop(j, i) = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);                           % real valued population
        population((((j-1)*nBits)+1):(j*nBits), i) = real2binary(realBetaPop(j, i), dBits, fBits);  % binary population
    end
end
%%------------------------------------ Generate Initial Population End----------------------------------------%%

%% SETUP for Twin Removal
cutoff = 1.0;                                   % starting CCF
aSimilarity = ceil(chromL * cutoff);            % allowable identical bits
cutoff_limit = 0.8;                             % minimum allowable CCF
cutoff_change = 0.00015;                        % rate of decreasing CCF
twin_removal_parameters = zeros(Max_Epoch, 2);  % storage for twin removal
%% SETUP for Twin Removal END

%% Substring Replica Parameter
sRate = 0.1;                                    % hGR rate
replacementFlag = 1;                            % replacement flag
gT_update_storage = zeros(epoch*nE, 6);         % hGR output storage: epoch, nE number, nReplica, old_perf_new_perf, ultimate_elite_perf
%% Substring Replica Parameter END

%tic;
%% Start evaluation

while (epoch < Max_Epoch)                   % outer loop with exit conditions
	nextGen = zeros(chromL, popSize);       % next generation initialization (binary)
    nextGenBeta = ones(nBeta, popSize);     % next generation initialization (real)
	
	%% calculate fitness of initial population
	for i = 1:popSize
        fitness_obj(i) = f11GriewankFunction(realBetaPop(:, i)); 
    end
    
    %% sort     
	[sortedFitness, id] = sort(fitness_obj, 'ascend'); 
    epoch  = epoch+1                                         % increase epoch
    optima = sortedFitness(1)                                % store optima
	
	%% setup for plotting
	Epo(epoch) = epoch;     
	Obj(epoch) = optima;	
    
    %% store corrent best
	if optima < Min_Obj
		Min_Obj = optima;
		Min_Obj_Epoch=epoch;
        best_beta = realBetaPop(:, id(1));
    end 
    
    %% check for termination condition reached or, not
    if Min_Obj == target_optima
        return;
    end
    
    %% Start preparaing new generation
	genId = 1;	% Its is a global counter to track how much of the next generation has been created  
    %% Preserve the Elite
	for i = 1:nE
		nextGen(:, i) = population(:, id(i));
        nextGenBeta(:, i) = realBetaPop(:, id(i));
		genId = genId + 1;
    end
    
    %% Generate good performing substring replica within Elite
    newElite_binary = zeros(1, chromL);                     % Initialize new Elite with replica (binary)
    newElite_real = zeros(1, nBeta);                        % Initialize new Elite with replica (real)
    
    for i = 1:nE
        sRate = 0.1;
        replacementFlag = 1;
        
        newElite_binary = nextGen(:, i);                    % Initialize new Elite with replica (binary)
        newElite_real = nextGenBeta(:, i);                  % Initialize new Elite with replica (real)
        
        oldElite_binary = nextGen(:, i);                    % Initialize new Elite with existing elite
        oldElite_real = nextGenBeta(:, i);                  % Initialize new Elite with existing elite
        
        wfX = zeros(1, nBeta);                              % contains fittness for each weight
        best_wX_real = 0;
        best_wX_binary = zeros(1, nBits);
        
        for j = 1:1:nBeta 
            wX = zeros(1, nBeta);                           % dimension reduce weight set
            wX(j) = newElite_real(j);                       % keep only one dimension
            wfX(j) = f11GriewankFunction(wX);                  % fitness contribution of this substring
        end
        
        [~, id_wfX] = sort(wfX, 'ascend');                  % sort in ascending order and find the best contribution
        
        best_wX_real = newElite_real(id_wfX(1));            % collect the best weight value (real and binary)
        best_wX_binary = newElite_binary(((((id_wfX(1)-1)*nBits)+1):(id_wfX(1)*nBits)));             
        
        [~, id_wfXR] = sort(wfX, 'descend');                % sort in descending order and find relatively worse contribution
        

        while(replacementFlag == 1)
            nSubstringReplica = ceil(nBeta * sRate);        % compute number of genes to be replaced
            if(nSubstringReplica > nBeta)                   % if enough gene is present
                nSubstringReplica = nBeta;                  
                replacementFlag = 0;
            end
            
            for j = 1:1:nSubstringReplica                   % replace
                newElite_real(id_wfXR(j)) = best_wX_real;
                newElite_binary(((((id_wfXR(j)-1)*nBits)+1):(id_wfXR(j)*nBits))) = best_wX_binary;
            end
            if(f11GriewankFunction(newElite_real) < f11GriewankFunction(nextGenBeta(:, i)))
                replacementFlag = 1;                        % if improved, replace more 
                nextGenBeta(:, i) = newElite_real;
                nextGen(:, i) = newElite_binary;
            else
                replacementFlag = 0;                        % if no improvement, then stop hGR 
            end
            sRate = sRate + 0.05;                           % increase hGR rate
        end    
        gT_update_storage(((epoch-1)*nE)+i, :) = [epoch i nSubstringReplica f11GriewankFunction(oldElite_real) f11GriewankFunction(newElite_real) f11GriewankFunction(nextGenBeta(:, i))] ;
    end
    
    
	%% Roulette Wheel
	
    totalFitness = sum(fitness_obj);
    pFitness = sortedFitness ./ totalFitness;
    pFitness = 1 - pFitness; % CHANGE (This is for minimization)
    
	%% FULL CROSSOVER START
	for i = 1:nC		
        %% Initialize return variables
        new1 = zeros(1, chromL);
        new2 = zeros(1, chromL);
        newReal1 = ones(1, nBeta);
        newReal2 = ones(1, nBeta);

        %% Select Candidate 1
        r1 = rand(1,1);                 % Select a random fitness
        j = 1;                          % Start for 1, since descending order sorting	
        while(r1 > 0) 
            r1 = r1 - pFitness(j);
            j = j + 1;
        end
        pick1 = id(j - 1);              % Pick Index of 1st candidate
        cand1 = population(:, pick1)';	

        %% Select Candidate 2
        r2 = rand(1,1);                 % Select a random fitness
        j = 1;                          % Start for 1, since descending order sorting                   
        while(r2 > 0)
            r2 = r2 - pFitness(j);
            j = j + 1;
        end
        pick2 = id(j - 1);
        cand2 = population(:, pick2)';  % Pick Index of 1st candidate

        %% Do Cross Over
        %% select single crossover point
        cPoint = ceil((chromL - 1) * (rand(1,1))); %% cross over point

        %% Cross and carete new 1
        new1 = [cand1(1 : cPoint) cand2(cPoint + 1 : chromL)];
        
        %% check whether this new chromosome is netter than current best
        newReal1 = zeros(1, nBeta);
        temp1 = zeros(1, nBits);
        for k = 1: nBeta
            temp1(1:nBits) = new1((((k-1)*nBits)+1):(k*nBits));
            temp1_real = binary2real(temp1, dBits, fBits);
            if (temp1_real < VRange(1)) || (temp1_real > VRange(2))               % Check range consistency
                temp1_real = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                new1((((k-1)*nBits)+1):(k*nBits)) = real2binary(temp1_real, dBits, fBits);
            end
            newReal1(k) = temp1_real;
        end
    
        %% Upper half

        %% Candidate one will be as it is and pieces of candidate 2 will be compared with AM pieces
        %% Cross and carete new 2
        new2 = [cand2(1 : cPoint) cand1(cPoint + 1 : chromL)];

        % check whether this new chromosome is netter than current best
        newReal2 = zeros(1, nBeta);
        temp2 = zeros(1, nBits);
        for k = 1: nBeta
            temp2(1:nBits) = new2((((k-1)*nBits)+1):(k*nBits));
            temp2_real = binary2real(temp2, dBits, fBits);
            if (temp2_real < VRange(1)) || (temp2_real > VRange(2))               % Check range consistency
                temp2_real = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                new2((((k-1)*nBits)+1):(k*nBits)) = real2binary(temp2_real, dBits, fBits);
            end
            newReal2(k) = temp2_real;
        end
        
		%% Place the new ones into next generation.
		nextGen( :, genId) = new1';
        nextGenBeta(:, genId) = newReal1';
		genId = genId + 1;
		nextGen( :, genId) = new2';
        nextGenBeta(:, genId) = newReal2';
		genId = genId + 1;
    end
    %% FULL CROSSOVER END
    
	%% Fill up the rest after crossover
	fllUp = (popSize - genId) + 1;
    temp_nextGen = zeros(1, nBits);
	for i = 1:fllUp
		nextGen(:, genId) = population(:, id(genId));
        for j = 1: nBeta
            temp_nextGen(1:nBits) = population((((j-1)*nBits)+1):(j*nBits), id(genId));              
			nextGenBeta(j, genId) = binary2real(temp_nextGen, dBits, fBits);
        end
		genId = genId + 1;
	end

	%% MUTATION
	for i = 1:nM
		ranPick = ceil((popSize - nE) * rand(1,1)) + nE;                % Random selection of candidate for mutation    
		candM = nextGen(:, ranPick)';                                   % candidate chromosome for mutation
        mPoint = ceil(chromL * (rand(1,1)));                            % Muttaion point
        if candM(mPoint) == 0
            candM(mPoint) = 1;                                          % flip bit
        elseif candM(mPoint) == 1
            candM(mPoint) = 0;                                          % flip bit
        end
        
        % check whether this new chromosome is netter than current best
        mutReal = zeros(1, nBeta);
        tempM = zeros(1, nBits);
        for k = 1: nBeta
			tempM(1:nBits) = candM((((k-1)*nBits)+1):(k*nBits));
            MReal = binary2real(tempM, dBits, fBits);
            if (MReal < VRange(1)) || (MReal > VRange(2))               % Check range consistency
                MReal = (VRange(2)-VRange(1)).*rand(1,1) + VRange(1);
                candM((((k-1)*nBits)+1):(k*nBits)) = real2binary(MReal, dBits, fBits);
            end
            mutReal(k) = MReal;
        end
        
        nextGen(:, ranPick) = candM';
        nextGenBeta(:, ranPick) = mutReal';
    end
    %% FULL MUTATION END
    
    %% Twin Removal
    nSimilar = 0;                                                       % numer of similar bits
    newRandom_binary = zeros(chromL, 1);
    newRandom_real = zeros(nBeta, 1);

    %% Check up for Twins and remove if any
    twin_count = 0;
    for p1=1:1:(popSize-1)                                              % first in pair
        for p2=(p1+1):1:popSize                                         % second in pair				
            nSimilar = length(find(nextGen(:,p1) == nextGen(:,p2)));    % count identical bits

            %% If twins
            if nSimilar >= aSimilarity                                  % check if the numbe identical bits exceeds the allowable ccf
                twin_count = twin_count + 1;                            
                if(f11GriewankFunction(nextGenBeta(:, p2)) < f11GriewankFunction(nextGenBeta(:, p1)))
                    nextGen(:, p1) = nextGen(:, p2);
                    nextGenBeta(:, p1) = nextGenBeta(:, p2);
                end
                newRandom_real = (VRange(2)-VRange(1)).*rand(nBeta,1) + VRange(1);
                for j = 1: nBeta
                    newRandom_binary((((j-1)*nBits)+1):(j*nBits)) = real2binary(newRandom_real(j), dBits, fBits);  % binary population
                end
                nextGen(:, p2) = newRandom_binary;
                nextGenBeta(:, p2) = newRandom_real;
            end
        end	
    end
    twin_removal_parameters(epoch, :) = [cutoff twin_count];
    if cutoff > cutoff_limit                                            % increase sequence identity cutoff to 80% max	
        cutoff = cutoff - cutoff_change;                                % Sequence identity cutoff 
        aSimilarity = chromL * cutoff;                                  % allowable identical bits
    end
    
    %% UPDATE BINARY POPULTAION WITH NEXT GENERATION
	population = nextGen;     
	realBetaPop = nextGenBeta;                                          % UPDATE REAL POPULTAION WITH NEXT GENERATION
    
end

