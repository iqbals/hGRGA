%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Schwefel's 1.2 Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Schwefel's 1.2 function
%}

function [fx] = f4Schwefel1_2Function(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end


sum = 0;
N = length(X);
for i = 1:N
    sum1 = 0;
    for j = 1:i
        sum1 = sum1 + X(j);
    end
    sum = sum + sum1^2;
end

fx =  sum;

%% END