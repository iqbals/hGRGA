%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Rastrigin Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Rastrigin function
%}

function [fx] = f6RastriginFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

sumForm = 0;
N = length(X);
for i = 1:N
    sumForm = sumForm + (X(i)^2 - 10*cos(2*pi*X(i)));
end

fx =  10*N + sumForm;

%% END