%{
Author: Sumaiya Iqbal, Computer Science, UNO ID # 2450707

Optimization Test Function Implementation
Levy 13
subject to -5 <= x(i) <= 10. 
The global minima is located at 
x* = f(0, 0), f(x*) = 0 
Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Levy13 function
%}

function [fx] = HappyCatFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

N = length(X);
fx =  ((abs(sum(X.^2)-N))^(1/4)) + (((0.5*sum(X.^2))+(sum(X)))/N) + (0.5);
%fx =  ((abs((sum(X.^2))^2 - (sum(X))^2))^(1/2)) + (((0.5*sum(X.^2))+(sum(X)))/N) + (0.5);
%% END