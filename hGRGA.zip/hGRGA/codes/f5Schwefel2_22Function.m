%{
Author: Sumaiya Iqbal (siqbal1@uno.edu) [2016]
Schwefel's 2.2 Optimization Test Function Implementation

Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Schwefel's 2.2 function
%}

function [fx] = f5Schwefel2_22Function(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

sum = 0;
mul = 1;

N = length(X);
for i = 1:N
    sum = sum + abs(X(i));
    mul = mul * abs(X(i));
end

fx =  sum + mul;

%% END