%{
Author: Sumaiya Iqbal, Computer Science, UNO ID # 2450707

Optimization Test Function Implementation
Levy 13
subject to -5 <= x(i) <= 10. 
The global minima is located at 
x* = f(0, 0), f(x*) = 0 
Input: 
X   ---> input vector with x(i) values
Output:
fx  ---> Output of Levy13 function
%}

function [fx] = SESWaveFunction(X)

%% Input parameter checking, if input vector is empty set default
if length(X) < 2
    error('Input should be at least two element vector');
end

N=length(X);
Y = zeros(2,1);
fx = 0;
for i=1:N
    if i==N
        Y(1) = X(N);
        Y(2) = X(1);
    else
        Y(1) = X(i);
        Y(2) = X(i+1);
    end
    
    fx =  fx + (0.5 + ((((sin(sqrt(sum(Y.^2))))^2) - 0.5) / (1 + (0.001*sum(Y.^2)))^2));
end


%% END